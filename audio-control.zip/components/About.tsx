import Image from "next/image"

export default function About() {
  return (
    <section id="about" className="py-16">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="About our company"
              width={600}
              height={400}
              className="rounded-lg shadow-md"
            />
          </div>
          <div className="md:w-1/2 md:pl-12">
            <h2 className="text-3xl font-bold mb-4">About Us</h2>
            <p className="text-gray-600 mb-4">
              We are a dedicated team committed to providing high-quality solutions for our clients. With years of
              experience and a passion for innovation, we strive to exceed expectations and deliver exceptional results.
            </p>
            <ul className="list-disc list-inside text-gray-600">
              <li>Expert team with diverse skills</li>
              <li>Cutting-edge technology and tools</li>
              <li>Customer-centric approach</li>
              <li>Continuous improvement and learning</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

