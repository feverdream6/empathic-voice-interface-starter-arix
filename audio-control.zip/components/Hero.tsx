import Link from "next/link"

export default function Hero() {
  return (
    <section className="bg-blue-600 text-white">
      <div className="container mx-auto px-6 py-16 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Welcome to Our Website</h1>
        <p className="text-xl mb-8">Discover amazing features and services</p>
        <Link
          href="#contact"
          className="bg-white text-blue-600 px-6 py-3 rounded-full font-bold hover:bg-blue-100 transition duration-300"
        >
          Get Started
        </Link>
      </div>
    </section>
  )
}

