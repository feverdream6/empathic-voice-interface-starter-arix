import { LightBulbIcon, SparklesIcon, ChartBarIcon } from "@heroicons/react/24/outline"

const features = [
  {
    name: "Intuitive Design",
    description: "Our user-friendly interface makes navigation a breeze.",
    icon: LightBulbIcon,
  },
  {
    name: "Powerful Features",
    description: "Packed with tools to help you achieve your goals.",
    icon: SparklesIcon,
  },
  {
    name: "Analytics",
    description: "Gain valuable insights with our advanced analytics.",
    icon: ChartBarIcon,
  },
]

export default function Features() {
  return (
    <section id="features" className="py-16 bg-gray-100">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-8">Our Features</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div key={feature.name} className="bg-white p-6 rounded-lg shadow-md">
              <feature.icon className="h-12 w-12 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{feature.name}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

