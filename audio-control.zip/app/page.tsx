"use client"

import { useState, useEffect } from "react"
import { useSpeechRecognition } from "react-speech-kit"

export default function Home() {
  const [isListening, setIsListening] = useState(false)
  const { listen, stop } = useSpeechRecognition({
    onResult: (result) => {
      // Handle the speech recognition result here
      console.log("Speech recognized:", result)
    },
  })

  // Function to play a beep sound
  const playBeep = (frequency: number, duration: number) => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    oscillator.type = "sine"
    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime)
    oscillator.connect(audioContext.destination)
    oscillator.start()
    oscillator.stop(audioContext.currentTime + duration)
  }

  const handleMicClick = () => {
    if (isListening) {
      stop()
      playBeep(800, 0.1) // Higher pitch beep for stop
    } else {
      listen()
      playBeep(400, 0.1) // Lower pitch beep for start
    }
    setIsListening(!isListening)
  }

  // Prevent scrolling
  useEffect(() => {
    document.body.style.overflow = "hidden"
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [])

  return (
    <main className="flex items-center justify-center min-h-screen bg-black">
      <button
        onClick={handleMicClick}
        className={`w-40 h-40 rounded-full transition-all ${
          isListening ? "bg-red-600 animate-pulse" : "bg-blue-600 hover:bg-blue-700"
        }`}
        aria-label={isListening ? "Stop listening" : "Start listening"}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth={2}
          stroke="currentColor"
          className="w-20 h-20 mx-auto"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z"
          />
        </svg>
      </button>
    </main>
  )
}

